# Changelog
This file is a running track of new features and fixes to each version of the panel released starting with `v3.0.0`.
