<?php

namespace Jexactyl\Contracts\Repository;

interface ApiPermissionRepositoryInterface extends RepositoryInterface
{
}
