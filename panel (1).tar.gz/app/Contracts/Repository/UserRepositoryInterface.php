<?php

namespace Jexactyl\Contracts\Repository;

interface UserRepositoryInterface extends RepositoryInterface
{
}
