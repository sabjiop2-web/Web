<?php

namespace Jexactyl\Contracts\Repository;

interface ServerVariableRepositoryInterface extends RepositoryInterface
{
}
