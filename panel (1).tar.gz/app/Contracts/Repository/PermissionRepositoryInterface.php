<?php

namespace Jexactyl\Contracts\Repository;

interface PermissionRepositoryInterface extends RepositoryInterface
{
}
