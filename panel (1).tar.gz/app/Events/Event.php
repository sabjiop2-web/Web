<?php

namespace Jexactyl\Events;

abstract class Event
{
}
