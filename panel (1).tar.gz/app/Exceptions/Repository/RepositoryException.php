<?php

namespace Jexactyl\Exceptions\Repository;

use Jexactyl\Exceptions\JexactylException;

class RepositoryException extends JexactylException
{
}
