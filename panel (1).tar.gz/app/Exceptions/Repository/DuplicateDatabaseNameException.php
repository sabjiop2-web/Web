<?php

namespace Jexactyl\Exceptions\Repository;

use Jexactyl\Exceptions\DisplayException;

class DuplicateDatabaseNameException extends DisplayException
{
}
