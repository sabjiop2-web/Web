<?php

namespace Jexactyl\Exceptions\Repository\Daemon;

use Jexactyl\Exceptions\Repository\RepositoryException;

class InvalidPowerSignalException extends RepositoryException
{
}
