<?php

namespace Jexactyl\Exceptions;

class AutoDeploymentException extends \Exception
{
}
