<?php

namespace Jexactyl\Exceptions\Transformer;

use Jexactyl\Exceptions\JexactylException;

class InvalidTransformerLevelException extends JexactylException
{
}
