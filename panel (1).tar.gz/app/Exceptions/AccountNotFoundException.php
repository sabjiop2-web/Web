<?php

namespace Jexactyl\Exceptions;

class AccountNotFoundException extends \Exception
{
}
