<?php

namespace Jexactyl\Exceptions\Http\Base;

use Jexactyl\Exceptions\DisplayException;

class InvalidPasswordProvidedException extends DisplayException
{
}
