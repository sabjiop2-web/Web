<?php

namespace Jexactyl\Exceptions\Http\Server;

use Jexactyl\Exceptions\DisplayException;

class FileTypeNotEditableException extends DisplayException
{
}
