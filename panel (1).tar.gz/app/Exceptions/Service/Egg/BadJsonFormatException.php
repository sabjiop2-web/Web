<?php

namespace Jexactyl\Exceptions\Service\Egg;

use Jexactyl\Exceptions\DisplayException;

class BadJsonFormatException extends DisplayException
{
}
