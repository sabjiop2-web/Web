<?php

namespace Jexactyl\Exceptions\Service\Egg\Variable;

use Jexactyl\Exceptions\DisplayException;

class BadValidationRuleException extends DisplayException
{
}
