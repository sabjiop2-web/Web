<?php

namespace Jexactyl\Exceptions\Service\Egg;

use Jexactyl\Exceptions\DisplayException;

class HasChildrenException extends DisplayException
{
}
