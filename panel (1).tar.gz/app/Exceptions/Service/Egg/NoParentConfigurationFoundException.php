<?php

namespace Jexactyl\Exceptions\Service\Egg;

use Jexactyl\Exceptions\DisplayException;

class NoParentConfigurationFoundException extends DisplayException
{
}
