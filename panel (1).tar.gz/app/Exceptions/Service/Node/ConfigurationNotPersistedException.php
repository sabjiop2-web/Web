<?php

namespace Jexactyl\Exceptions\Service\Node;

use Jexactyl\Exceptions\DisplayException;

class ConfigurationNotPersistedException extends DisplayException
{
}
