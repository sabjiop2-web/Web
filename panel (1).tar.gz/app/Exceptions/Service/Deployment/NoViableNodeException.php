<?php

namespace Jexactyl\Exceptions\Service\Deployment;

use Jexactyl\Exceptions\DisplayException;

class NoViableNodeException extends DisplayException
{
}
