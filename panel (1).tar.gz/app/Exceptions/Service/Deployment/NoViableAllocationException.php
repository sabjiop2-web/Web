<?php

namespace Jexactyl\Exceptions\Service\Deployment;

use Jexactyl\Exceptions\DisplayException;

class NoViableAllocationException extends DisplayException
{
}
