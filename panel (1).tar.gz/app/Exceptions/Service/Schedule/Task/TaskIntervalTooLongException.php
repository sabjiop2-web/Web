<?php

namespace Jexactyl\Exceptions\Service\Schedule\Task;

use Jexactyl\Exceptions\DisplayException;

class TaskIntervalTooLongException extends DisplayException
{
}
