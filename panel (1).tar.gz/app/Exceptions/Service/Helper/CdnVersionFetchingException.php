<?php

namespace Jexactyl\Exceptions\Service\Helper;

class CdnVersionFetchingException extends \Exception
{
}
