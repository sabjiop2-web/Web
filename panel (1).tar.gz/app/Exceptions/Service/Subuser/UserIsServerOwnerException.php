<?php

namespace Jexactyl\Exceptions\Service\Subuser;

use Jexactyl\Exceptions\DisplayException;

class UserIsServerOwnerException extends DisplayException
{
}
