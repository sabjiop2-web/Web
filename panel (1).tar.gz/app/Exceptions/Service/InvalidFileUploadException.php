<?php

namespace Jexactyl\Exceptions\Service;

use Jexactyl\Exceptions\DisplayException;

class InvalidFileUploadException extends DisplayException
{
}
