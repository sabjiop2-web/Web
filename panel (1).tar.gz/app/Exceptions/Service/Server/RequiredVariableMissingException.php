<?php

namespace Jexactyl\Exceptions\Service\Server;

use Jexactyl\Exceptions\JexactylException;

class RequiredVariableMissingException extends JexactylException
{
}
