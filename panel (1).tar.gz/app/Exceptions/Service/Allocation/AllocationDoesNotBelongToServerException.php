<?php

namespace Jexactyl\Exceptions\Service\Allocation;

use Jexactyl\Exceptions\JexactylException;

class AllocationDoesNotBelongToServerException extends JexactylException
{
}
