<?php

namespace Jexactyl\Exceptions\Service\Allocation;

use Jexactyl\Exceptions\DisplayException;

class ServerUsingAllocationException extends DisplayException
{
}
